# Screen resolution
width, height = 400, 400

# Define colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# Define the initial eye positions
eye_x: int = width // 2
eye_y: int = height // 2

