import pygame
import sys
import cv2 as cv

from face_objects.eyes import Eyes
from face_objects.eyelids import Eyelids
from face_objects.mouth import Mouth
from face_objects.eyebrows import Eyebrows
from face_objects.mustache import Mustache
from face_objects.nose import Nose

from rgbmatrix import RGBMatrix, RGBMatrixOptions
from PIL import Image
    
# Initialize Pygame
pygame.init()

# Set up the display window
width, height = 400, 400
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption("Moving Pupils")

# Define colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
        
class Face:
        
    def __init__(self) -> None:
        
        self.eyes = Eyes(screen)
        self.eyelids = Eyelids(screen, .2, 3)
        self.eyebrows = Eyebrows(screen, 1, 5)
        self.nose = Nose(screen)
        self.mustache = Mustache(screen)
        self.mouth = Mouth(screen, .1, .1, 120)

        
    def draw_face(self, mouse_x, mouse_y):
        self.mouse_x = mouse_x
        self.mouse_y = mouse_y
        self.mouth.set_talking(True)
        self.eyes.draw(mouse_x, mouse_y)
        self.eyelids.draw()
        self.eyebrows.draw()
        self.nose.draw()
        self.mustache.draw()
        self.mouth.draw()
    
    
face = Face()

cap = cv.VideoCapture(0)

if not cap.isOpened():
    print("Cannot open camera")
    exit()
    
# Run the game loop
x = 0
y = 0
w = 0
h = 0

while True:
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    ret, frame = cap.read()
    if not x:
        x = frame.shape[1]//2
    
    if not y:
        y = frame.shape[0]//2
    # if frame is read correctly ret is True
    if not ret:
        print("Can't receive frame (stream end?). Exiting ...")
        break
    # Our operations on the frame come here
    gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
    gray = cv.flip(gray, 1)
    face_classifier = cv.CascadeClassifier(
        cv.data.haarcascades + "haarcascade_frontalface_default.xml"
    )
    cv_face = face_classifier.detectMultiScale(
        gray, scaleFactor=1.1, minNeighbors=5, minSize=(40, 40)
    )
    
    # Clear the screen
    screen.fill(BLACK)

    # Update the pupil position based on mouse movement
    mouse_x, mouse_y = pygame.mouse.get_pos()
    if len(cv_face):
        x, y, w, h = cv_face[0]
    
    face.draw_face((x+w//2)/frame.shape[1]*400, (y+h//2)/frame.shape[0]*400)
    
    # Update the display
    pygame.image.save(screen, './screen.png')
    image = Image.open('./screen.png')

    # Configuration for the matrix
    options = RGBMatrixOptions()
    options.rows = 64
    options.cols = 64
    options.chain_length = 1
    options.parallel = 1
    options.hardware_mapping = 'regular'  # If you have an Adafruit HAT: 'adafruit-hat'

    matrix = RGBMatrix(options = options)

    # Make image fit our screen.
    image.thumbnail((matrix.width, matrix.height), Image.ANTIALIAS)

    matrix.SetImage(image.convert('RGB'))
