from .abstract import FaceObject
import pygame
from config import BLACK, WHITE
import random
import time
from .utils import get_rect


class Mustache(FaceObject):
    
    def __init__(self, screen) -> None:
        super().__init__(None, None)
        
        self.screen = screen
        self.width = screen.get_width()
        self.height = screen.get_height()
        
        # Define the initial eye positions
        self.mustache_matrix = [
            [self.width//2-80, self.height//2+50], 
            [self.width//2+80, self.height//2+50],
            [self.width//2+100, self.height//2+90], 
            [self.width//2-100, self.height//2+90],
        ]
        
    def draw(self):
        pygame.draw.polygon(self.screen, WHITE, self.mustache_matrix)