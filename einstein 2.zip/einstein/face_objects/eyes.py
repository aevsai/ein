from .abstract import FaceObject
import pygame
from config import BLACK, WHITE


class Eyes(FaceObject):
    
    def __init__(self, screen) -> None:
        super().__init__(None, None)
        
        self.screen = screen
        self.width = screen.get_width()
        self.height = screen.get_height()
        
        self.eye_x = self.width // 2
        self.eye_y = self.height // 2 - 40
        self.pupil_x = self.eye_x
        self.pupil_y = self.eye_y
        self.eyeball_radius = 30
        self.pupil_radius = 10
        self.eyes_distance = 160
        
        self.speed = 2
        self.max_distance = 40
        
    def draw(self, mouse_x, mouse_y):
        pupil_x = self.eye_x + (mouse_x - self.eye_x) * (self.max_distance / self.width)
        pupil_y = self.eye_y + (mouse_y - self.eye_y) * (self.max_distance / self.height)
        
        # Draw the eyeballs
        pygame.draw.circle(self.screen, BLACK, (self.eye_x - self.eyes_distance//2, self.eye_y), self.eyeball_radius)
        pygame.draw.circle(self.screen, BLACK, (self.eye_x + self.eyes_distance//2, self.eye_y), self.eyeball_radius)
        
        # Draw the pupils
        pygame.draw.circle(self.screen, WHITE, (pupil_x - self.eyes_distance//2, pupil_y), self.pupil_radius)
        pygame.draw.circle(self.screen, WHITE, (pupil_x + self.eyes_distance//2, pupil_y), self.pupil_radius)