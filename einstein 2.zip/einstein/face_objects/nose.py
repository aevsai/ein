from .abstract import FaceObject
import pygame
from config import BLACK, WHITE
import random
import time
from .utils import get_rect


class Nose(FaceObject):
    
    def __init__(self, screen) -> None:
        super().__init__(None, None)
        
        self.screen = screen
        self.width = screen.get_width()
        self.height = screen.get_height()
        
        
    def draw(self):
        pi = 3.14
        pygame.draw.arc(self.screen, WHITE, (self.width//2-25, self.height//2, 30, 30), pi/2, -pi/3, 4)