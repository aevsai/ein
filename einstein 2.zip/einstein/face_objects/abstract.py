from abc import ABC, abstractclassmethod
import time
import enum


class FaceObject(ABC):
    
    
    def __init__(self, duration, interval) -> None:
        super().__init__()
        
        self.last_event_time = time.time()
        self.event_duration = duration
        self.event_interval = interval
        self.is_event = False
        
    @abstractclassmethod
    def draw(self):
        pass
    
    
class Emotions(enum.Enum):
    HAPPY = 'happy'
    SAD = 'sad'
    SURPRISED = 'surprised'
    ANGRY = 'angry'
    FEARFUL = 'fearful'
    DISGUSTED = 'disgusted'
    BAD = 'bad'
    DEFAULT = 'default'
    
