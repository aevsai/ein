from .abstract import FaceObject
import pygame
from config import BLACK, WHITE
import random
import time
from .utils import get_rect


class Mouth(FaceObject):
    
    def __init__(self, screen, duration, interval, mouth_width) -> None:
        super().__init__(duration, interval)
        
        self.screen = screen
        self.width = screen.get_width()
        self.height = screen.get_height()
        
        self.mouth = pygame.Rect(
            self.width//2-mouth_width//2,
            self.height//2+110,
            mouth_width,
            5
        )
        
        self.mouth_width = mouth_width
        self.mouth_move_rec = self.mouth
        self.mouth_angle = 0
        
    def draw(self):
        current_time = time.time()
        if self.is_event:
            if current_time - self.last_event_time > self.event_duration:
                self.last_event_time = current_time
                self.mouth_move_rec = self.mouth
                self.mouth_move_rec.height = random.randint(5, 40)
                current_mouth_width = random.randint(60, self.mouth_width)
                self.mouth_move_rec.width = current_mouth_width
                self.mouth_move_rec.centerx = self.width//2
                self.mouth_angle = random.randint(-5, 5)
            pygame.draw.polygon(self.screen, WHITE, get_rect(self.mouth_move_rec, self.mouth_angle))
        else:
            pygame.draw.polygon(self.screen, WHITE, get_rect(self.mouth, 0))
            
    def set_talking(self, is_event):
        self.is_event = is_event