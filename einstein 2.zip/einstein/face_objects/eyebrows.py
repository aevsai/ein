from .abstract import FaceObject
import pygame
from config import BLACK, WHITE
import random
import time
from .utils import get_rect


class Eyebrows(FaceObject):
    
    def __init__(self, screen, duration, interval) -> None:
        super().__init__(duration, interval)
        
        self.screen = screen
        self.width = screen.get_width()
        self.height = screen.get_height()
        
        # Define the initial eye positions
        self.eye_x = self.width // 2
        self.eye_y = self.height // 2 - 40
        self.eyeball_radius = 30
        self.eyes_distance = 160
        
        self.left_eyebrow_rect = pygame.Rect(
            self.eye_x - self.eyes_distance // 2 - self.eyeball_radius*1.5, 
            self.eye_y - self.eyeball_radius * 1.5,
            80,
            15
        )
        
        self.right_eyebrow_rect = pygame.Rect(
            self.eye_x + self.eyes_distance // 2 - self.eyeball_radius*1.5, 
            self.eye_y - self.eyeball_radius * 1.5,
            80,
            15
        )
        
        self.centery_left = self.left_eyebrow_rect.centery
        self.centery_right = self.right_eyebrow_rect.centery
        
    def draw(self):
        current_time = time.time()
        if not self.is_event and current_time - self.last_event_time > self.event_interval:
            self.is_event = True
            self.last_event_time = current_time
            
        if not self.is_event:
            # Draw the eyelids
            pygame.draw.polygon(self.screen, WHITE, get_rect(self.left_eyebrow_rect, 5))
            pygame.draw.polygon(self.screen, WHITE, get_rect(self.right_eyebrow_rect, -5))
        else:
            # Calculate the height of the closed eyelid based on the blink duration
            self.event_progress = (current_time - self.last_event_time) / self.event_duration
            if self.event_progress < 0.5:
                angle = int(self.event_progress * 30)
                bias = int(self.event_progress * 80)
                if angle > 30:
                    angle = 30
                if bias > 80:
                    bias = 80
            else:
                angle = int((1-self.event_progress) * 30)
                bias = int((1-self.event_progress) * 80)
                if angle > 30:
                    angle = 30
                if bias > 80:
                    bias = 80

            self.left_eyebrow_rect.centery = self.centery_left - bias
            self.right_eyebrow_rect.centery = self.centery_right - bias
            # Draw the closed eyelids
            pygame.draw.polygon(self.screen, WHITE, get_rect(self.left_eyebrow_rect, angle))
            pygame.draw.polygon(self.screen, WHITE, get_rect(self.right_eyebrow_rect, -angle))
            
            # Check if the blink is complete
            if self.event_progress >= 1.0:
                self.is_event = False
                
        
