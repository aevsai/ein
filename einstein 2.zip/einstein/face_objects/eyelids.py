from .abstract import FaceObject
import pygame
from config import BLACK, WHITE
import time
import random

class Eyelids(FaceObject):
    
    def __init__(self, screen, duration, interval) -> None:
        super().__init__(duration, interval)
        
        self.screen = screen
        self.width = screen.get_width()
        self.height = screen.get_height()
        
        self.eye_x = self.width // 2
        self.eye_y = self.height // 2 - 40
        self.pupil_x = self.eye_x
        self.pupil_y = self.eye_y
        self.eyeball_radius = 30
        self.eyes_distance = 160

    def draw(self):
        current_time = time.time()
        if not self.is_event and current_time - self.last_event_time > self.event_interval:
            self.is_event = True
            self.last_event_time = current_time
            
        if not self.is_event:
            # Draw the eyelids
            pygame.draw.line(self.screen, BLACK, (self.eye_x - self.eyes_distance, self.eye_y - 40), (self.eye_x + self.eyes_distance, self.eye_y - 40), self.eyeball_radius*2)
            pygame.draw.line(self.screen, BLACK, (self.eye_x - self.eyes_distance, self.eye_y - 40), (self.eye_x + self.eyes_distance, self.eye_y - 40), self.eyeball_radius*2)
        else:
            # Calculate the height of the closed eyelid based on the blink duration
            self.blink_progress = (current_time - self.last_event_time) / self.event_duration
            if self.blink_progress < 0.5:
                eyelid_y = int(self.blink_progress * 2 * 40)
                if eyelid_y > 40:
                    eyelid_y = 40
            else:
                eyelid_y = int((1-self.blink_progress) * 2 * 40)
                if eyelid_y > 40:
                    eyelid_y = 40

            # Draw the closed eyelids
            pygame.draw.line(self.screen, BLACK, (self.eye_x - self.eyes_distance, self.eye_y - 40 + eyelid_y), (self.eye_x + self.eyes_distance, self.eye_y - 40 + eyelid_y), self.eyeball_radius*2)
            pygame.draw.line(self.screen, BLACK, (self.eye_x - self.eyes_distance, self.eye_y - 40 + eyelid_y), (self.eye_x + self.eyes_distance, self.eye_y - 40 + eyelid_y), self.eyeball_radius*2)

            # Check if the blink is complete
            if self.blink_progress >= 1.0:
                self.is_event = False
                self.event_interval = random.randint(0, 5)